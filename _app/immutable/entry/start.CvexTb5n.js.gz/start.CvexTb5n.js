import{a as t}from"../chunks/entry.D-0n4E3A.js";export{t as start};
