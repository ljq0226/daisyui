import{a as t}from"../chunks/entry.CT2uOKmL.js";export{t as start};
