import{a as t}from"../chunks/entry.QSPrfi3d.js";export{t as start};
